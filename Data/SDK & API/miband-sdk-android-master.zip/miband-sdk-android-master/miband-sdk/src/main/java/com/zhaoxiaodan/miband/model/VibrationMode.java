/**
 *
 */
package com.zhaoxiaodan.miband.model;

public enum VibrationMode {
    VIBRATION_WITH_LED, VIBRATION_10_TIMES_WITH_LED, VIBRATION_WITHOUT_LED
}
