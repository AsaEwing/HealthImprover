package com.zhaoxiaodan.miband.listeners;

public interface RealtimeStepsNotifyListener {
    public void onNotify(int steps);
}
