package com.zhaoxiaodan.miband.model;


public enum LedColor {
    RED, BLUE, ORANGE, GREEN,
}
