package com.zhaoxiaodan.miband.listeners;

public interface NotifyListener {
    public void onNotify(byte[] data);
}
